let r={enabled:!0,highlightImages:!0,showImageInfo:!1};const x=()=>{chrome.runtime.sendMessage({action:"getHelperConfig"},t=>{t&&t.config&&(r={...r,...t.config},r.enabled&&w())})},L=()=>{chrome.runtime.sendMessage({action:"openOptionsPage"},t=>{(!t||!t.success)&&console.error("打开设置页面失败")})},I=t=>{var i,o,s,c;const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    z-index: 10000;
    font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
    min-width: 400px;
  `,e.innerHTML=`
    <style>
      .aihcx-radio {
        position: relative;
        display: flex;
        align-items: center;
        gap: 8px;
        cursor: pointer;
      }
      
      .aihcx-radio input[type="radio"] {
        position: absolute;
        opacity: 0;
        width: 0;
        height: 0;
      }
      
      .aihcx-radio .radio-custom {
        width: 16px;
        height: 16px;
        border: 2px solid #ddd;
        border-radius: 50%;
        display: inline-block;
        position: relative;
      }
      
      .aihcx-radio input[type="radio"]:checked + .radio-custom {
        border-color: #4285f4;
      }
      
      .aihcx-radio input[type="radio"]:checked + .radio-custom::after {
        content: '';
        width: 8px;
        height: 8px;
        background: #4285f4;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        border-radius: 50%;
      }
      
      .aihcx-radio:hover .radio-custom {
        border-color: #4285f4;
      }
    </style>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <span style="font-size: 16px; color: #333;">关闭悬浮按钮</span>
      <button id="close-dialog" style="border: none; background: none; cursor: pointer; font-size: 18px; color: #999;">×</button>
    </div>
    <div style="display: flex; flex-direction: column; gap: 12px;">
      <label class="aihcx-radio">
        <input type="radio" name="close-option" value="current-visit" checked>
        <span class="radio-custom"></span>
        <span style="color: #333;">在本次访问关闭</span>
      </label>
      <label class="aihcx-radio">
        <input type="radio" name="close-option" value="current-page">
        <span class="radio-custom"></span>
        <span style="color: #333;">在本页关闭</span>
      </label>
      <label class="aihcx-radio">
        <input type="radio" name="close-option" value="all">
        <span class="radio-custom"></span>
        <span style="color: #333;">全部关闭</span>
      </label>
      <div style="color: #999; font-size: 12px; margin-left: 24px;">
        可在 <a href="#" id="settings-link" style="color: #4285f4; text-decoration: none;">设置</a> 中开启
      </div>
    </div>
    <div style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 20px;">
      <button id="cancel-close" style="
        padding: 6px 16px;
        border: 1px solid #ddd;
        background: white;
        border-radius: 4px;
        cursor: pointer;
        color: #333;
      ">取消</button>
      <button id="confirm-close" style="
        padding: 6px 16px;
        border: none;
        background: #4285f4;
        border-radius: 4px;
        cursor: pointer;
        color: white;
      ">确定</button>
    </div>
  `,document.body.appendChild(e);const n=()=>{document.body.removeChild(e)};(i=e.querySelector("#close-dialog"))==null||i.addEventListener("click",n),(o=e.querySelector("#cancel-close"))==null||o.addEventListener("click",n),(s=e.querySelector("#settings-link"))==null||s.addEventListener("click",l=>{l.preventDefault(),L(),n()}),(c=e.querySelector("#confirm-close"))==null||c.addEventListener("click",()=>{switch(e.querySelector('input[name="close-option"]:checked').value){case"current-visit":t.remove();break;case"current-page":const d=window.location.pathname;chrome.storage.local.get(["aihcx-helper-disabled-pages"],h=>{const p=h["aihcx-helper-disabled-pages"]||[];p.includes(d)?t.remove():(p.push(d),chrome.storage.local.set({"aihcx-helper-disabled-pages":p},()=>{t.remove()}))});break;case"all":chrome.storage.local.set({"aihcx-helper-disabled":!0},()=>{t.remove()});break}n()})},f=()=>{chrome.storage.local.get(["aihcx-helper-disabled-pages"],t=>{const e=t["aihcx-helper-disabled-pages"]||[],n=window.location.pathname;if(e.includes(n))return;const i=document.createElement("div");i.id="aihcx-helper-container",i.style.cssText=`
      position: fixed;
      bottom: 20px;
      right: 20px;
      display: flex;
      align-items: center;
      background-color: #4285f4;
      border-radius: 4px;
      cursor: move;
      font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
      z-index: 9999;
      box-shadow: 0 2px 5px rgba(0,0,0,0.2);
      user-select: none;
    `;const o=document.createElement("button");o.id="aihcx-helper-button",o.textContent="AIHC助手",o.style.cssText=`
      padding: 10px 15px;
      background: none;
      color: white;
      border: none;
      cursor: pointer;
      font-family: inherit;
    `;const s=document.createElement("button");s.id="aihcx-helper-close",s.textContent="×",s.style.cssText=`
      padding: 10px;
      background: none;
      color: white;
      border: none;
      border-left: 1px solid rgba(255,255,255,0.2);
      cursor: pointer;
      font-size: 18px;
      display: flex;
      align-items: center;
    `,o.addEventListener("click",a=>{a.stopPropagation(),chrome.runtime.sendMessage({action:"openPopup"})}),s.addEventListener("click",a=>{a.stopPropagation(),I(i)});let c=!1,l=0,d=0,h=0,p=0,u=0,g=0;const k=a=>{h=a.clientX-u,p=a.clientY-g,(a.target===i||a.target===o)&&(c=!0)},E=a=>{c&&(a.preventDefault(),l=a.clientX-h,d=a.clientY-p,u=l,g=d,i.style.transform=`translate(${l}px, ${d}px)`)},C=()=>{c&&(c=!1,chrome.storage.local.set({"aihcx-helper-position":{x:u,y:g}}))};chrome.storage.local.get(["aihcx-helper-position"],a=>{if(a["aihcx-helper-position"]){const{x:b,y}=a["aihcx-helper-position"];u=b,g=y,i.style.transform=`translate(${b}px, ${y}px)`}}),i.addEventListener("mousedown",k),document.addEventListener("mousemove",E),document.addEventListener("mouseup",C),i.appendChild(o),i.appendChild(s),document.body.appendChild(i)})},w=()=>{r.highlightImages&&P()},P=()=>{document.querySelectorAll("img").forEach(e=>{e.width>100&&e.height>100&&(e.style.border="2px solid #4285f4",e.addEventListener("click",n=>{if(r.enabled){n.preventDefault(),n.stopPropagation();const i={src:e.src,width:e.width,height:e.height,alt:e.alt||"无描述",pageUrl:window.location.href};chrome.runtime.sendMessage({action:"processImage",imageInfo:i},o=>{o&&o.success&&r.showImageInfo&&S(i)})}}),e.addEventListener("mouseover",()=>{r.enabled&&(e.style.cursor="pointer",e.style.boxShadow="0 0 15px rgba(66, 133, 244, 0.5)")}),e.addEventListener("mouseout",()=>{e.style.boxShadow="none"}))})},S=t=>{var n,i;const e=document.createElement("div");e.className="aihcx-image-info-popup",e.style.cssText=`
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    z-index: 10000;
    max-width: 80%;
    font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
  `,e.innerHTML=`
    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
      <h3 style="margin: 0;">图像信息</h3>
      <button id="close-popup" style="background: none; border: none; font-size: 18px; cursor: pointer;">×</button>
    </div>
    <div style="margin-bottom: 10px;">
      <div><strong>尺寸:</strong> ${t.width}×${t.height}</div>
      <div><strong>描述:</strong> ${t.alt}</div>
      <div style="word-break: break-all;"><strong>URL:</strong> ${t.src}</div>
    </div>
    <div style="text-align: center;">
      <button id="process-image" style="padding: 8px 15px; background: #4285f4; color: white; border: none; border-radius: 4px; cursor: pointer;">
        添加到任务
      </button>
    </div>
  `,document.body.appendChild(e),(n=document.getElementById("close-popup"))==null||n.addEventListener("click",()=>{document.body.removeChild(e)}),(i=document.getElementById("process-image"))==null||i.addEventListener("click",()=>{chrome.runtime.sendMessage({action:"addImageToTask",imageInfo:t},o=>{o&&o.success&&document.body.removeChild(e)})})},m=()=>window.location.href.startsWith("https://console.bce.baidu.com/aihc");document.readyState==="complete"?m()&&chrome.storage.local.get(["aihcx-helper-disabled"],t=>{t["aihcx-helper-disabled"]||(f(),x())}):window.addEventListener("load",()=>{m()&&chrome.storage.local.get(["aihcx-helper-disabled"],t=>{t["aihcx-helper-disabled"]||(f(),x())})});let v=window.location.href;new MutationObserver(()=>{const t=window.location.href;if(t!==v){v=t;const e=document.getElementById("aihcx-helper-container");e&&e.remove(),m()&&chrome.storage.local.get(["aihcx-helper-disabled"],n=>{n["aihcx-helper-disabled"]||(f(),x())})}}).observe(document,{subtree:!0,childList:!0});chrome.runtime.onMessage.addListener((t,e,n)=>{if(t.action==="getPageInfo"){const i={title:document.title,url:window.location.href,images:Array.from(document.querySelectorAll("img")).filter(o=>o.width>100&&o.height>100).map(o=>({src:o.src,width:o.width,height:o.height,alt:o.alt||"无描述"}))};n(i)}return t.action==="updateConfig"&&(r={...r,...t.config},r.enabled&&r.highlightImages&&w(),n({success:!0})),!0});
